package comp.cw1.pkg2022;

import java.io.FileWriter;
import java.io.IOException;

public class StaffBST implements IStaffDB {
    private Node root;
    private static FileWriter logFile;

    static {
        try {
            logFile = new FileWriter("log.txt", false); // Use "true" to append to the existing log file
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public StaffBST() {
        System.out.println("Binary Search Tree");
    }

    private static class Node {
        Employee employee;
        Node left, right;

        Node(Employee employee) {
            this.employee = employee;
            this.left = null;
            this.right = null;
        }
    }

    @Override
    public void clearDB() {
        root = null;
    }

    @Override
    public boolean containsName(String name) {
        return containsName(root, name);
    }

    private boolean containsName(Node node, String name) {
        if (node == null)
            return false;


        int cmp = name.compareTo(node.employee.getName());
        if (cmp < 0)
            return containsName(node.left, name);
        else if (cmp > 0)
            return containsName(node.right, name);
        else
            return true; // Employee found

    }

    @Override
    public Employee get(String name) {
        return get(root, name);
    }

    private Employee get(Node node, String name) {
        if (node == null)
            return null;


        int cmp = name.compareTo(node.employee.getName());
        if (cmp < 0)
            return get(node.left, name);
        else if (cmp > 0)
            return get(node.right, name);
        else
            return node.employee; // Employee found
    }

    @Override
    public int size() { return size(root); }

    private int size(Node node) {
        if (node == null)
            return 0;

        return 1 + size(node.left) + size(node.right);
    }

    @Override
    public boolean isEmpty() { return root == null; }

    @Override
    public Employee put(Employee employee) {
        Employee employee_test = get(employee.getName());
        root = put(root, employee);
        if(employee_test != null){
            logEmployeeInfo("Updation", employee);
            return employee_test;
        }
        else{
            logEmployeeInfo("Insertion", employee);
            return null;
        }
    }

    private Node put(Node node, Employee employee) {
        if (node == null)
            return new Node(employee);

        int cmp = employee.getName().compareTo(node.employee.getName());
        if (cmp < 0)
            node.left = put(node.left, employee);
        else if (cmp > 0)
            node.right = put(node.right, employee);
        else {
            // Duplicate employee name, update the affiliation
            node.employee = employee;
            return node;
        }
        return node;
    }

    @Override
    public Employee remove(String name) {
        // Initialize root and parent pointers to null
        Node current = root;
        Node parent = null;


        // Search for the node to be removed
        while (current != null) {
            int cmp = name.compareTo(current.employee.getName());

            if (cmp < 0) {
                parent = current;
                current = current.left;
            } else if (cmp > 0) {
                parent = current;
                current = current.right;
            } else {
                // Node with the given name found, remove it
                Employee removedEmployee = current.employee;
                removeNode(parent, current);
                logEmployeeInfo("deletion", removedEmployee);
                return removedEmployee;
            }
        }

        // Node with the given name not found
        return null;
    }

    private void removeNode(Node parent, Node nodeToRemove) {
        if (nodeToRemove.left == null && nodeToRemove.right == null) {
            // Case 1: Node to be removed is a leaf
            if (parent == null)
                root = null; // Node to be removed is the root
            else if (parent.left == nodeToRemove)
                parent.left = null;
            else
                parent.right = null;

        } else if (nodeToRemove.left == null || nodeToRemove.right == null) {
            // Case 2: Node to be removed has one child
            Node child = (nodeToRemove.left != null) ? nodeToRemove.left : nodeToRemove.right;

            if (parent == null)
                // Node to be removed is the root
                root = child;
            else if (parent.left == nodeToRemove)
                parent.left = child;
            else
                parent.right = child;

        } else {
            // Case 3: Node to be removed has two children
            Node successor = findSuccessor(nodeToRemove);
            nodeToRemove.employee = successor.employee;
            removeNode(nodeToRemove, successor);
        }
    }

    private Node findSuccessor(Node node) {
        Node successorParent = node;
        Node successor = node.right;

        while (successor.left != null) {
            successorParent = successor;
            successor = successor.left;
        }

        if (successorParent != node)
            successorParent.left = successor.right;
        else
            node.right = successor.right;

        return successor;
    }


    @Override
    public void displayDB() {
        displayDB(root);
    }

    private void displayDB(Node node) {
        if (node != null) {
            displayDB(node.left);
            System.out.println(node.employee.toString());
            displayDB(node.right);
        }
    }

    public void logEmployeeInfo(String operation, Employee employee) {
        try {
            logFile.write("Operation: " + operation + "\n");
            logFile.write("Employee Name: " + employee.getName() + "\n");
            logFile.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

