package comp.cw1.pkg2022;

public interface IEmployee {
    public String getName();
    public String getAffiliation();
    public String toString();
}
